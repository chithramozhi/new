sap.ui.define([],function(){"use strict";return{}});
//# sourceMappingURL=formatter.js.map